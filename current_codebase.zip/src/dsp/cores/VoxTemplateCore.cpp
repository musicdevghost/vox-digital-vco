#include "dsp/cores/VoxTemplateCore.hpp"
// All methods are inline in the header for this simple template.
